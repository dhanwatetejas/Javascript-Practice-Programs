// check wheather the letters in the given string are unique?
function unique(str){
let letters = str.split("");
let values = [];
// console.log(word);
for(let letter of letters){
    // console.log(values.indexOf(letter));
    
    if(values.indexOf(letter)!==-1){
        return false;
    }
    values.push(letter);
}
     return true;
}

console.log(unique("abcde"));
console.log(unique("abcdeabe"));