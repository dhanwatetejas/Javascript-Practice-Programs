let property = [
    {
        title: "Iphone",
        company:"Apple"
    },
    {
        title: "S3",
        company:"Samsung"
    },
    {
        title: "Guru",
        company:"Nokia"
    },
    {
        title: "JioPhone",
        company:"Jio"
    },
    {
        title: "Iphone2",
        company:"Apple"
    },
    {
        title: "HTC1",
        company:"Htc"
    }
]
function uniProperty(arr){
    let tempArr = arr.map(item => item.company);
    return [... new Set(tempArr)];

}
console.log(uniProperty(property));