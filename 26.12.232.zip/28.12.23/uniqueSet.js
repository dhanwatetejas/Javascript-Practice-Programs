function check(str){
    let str1 = new Set();
    for(let letter of str){
        if(str1.has(letter)){
            return false;
        }
        str1.add(letter);
    }
    return true;

}
console.log(check("abcde"));
console.log(check("abcbdea"));
