//check if the largest number in the array is equal to addition of the remaining array elements 
function arraySum(arr){
let tempArr = arr.sort((a,b)=>{
    return a-b;
}) 
let largest= tempArr.pop();

// return tempArr;
let sum = 0;
for (let value of arr){
    sum = sum+ value;
}
if(sum==largest){
    return true;
}
else return false ;
}
console.log(arraySum([1,2,3,4,10]));
console.log(arraySum([10,20,30,40]));
