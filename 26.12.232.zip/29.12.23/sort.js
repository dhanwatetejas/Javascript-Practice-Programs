// sort the given string alphabtically

function arrange(str){
    let str1= str.split("");
    let sorted = str1.sort();
    console.log(sorted);
}
console.log(arrange("Philadephia"));