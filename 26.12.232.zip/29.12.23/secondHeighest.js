// return the values which are 2nd lowest and second heighest
function check(arr){
    let values =[...new Set(arr)].sort((a,b) => {return a-b});
    console.log(values);

    if(values.length >3){

    return `lowEnd = ${values[1]} highEnd = ${values[values.length -2]}`
    }
    if(values.length==3){
        return `center = ${values[1]}`;
    }
    if(values.length==2){
        return `lowEnd = ${values[0]} highEnd = ${values[1]} `;
    }
    else return `single number is ${values[0]}`;
    
}

console.log(check([3,2,-11,5,77,3,45]));
console.log(check([33,56,23]));
console.log(check([1,2]));
console.log(check([23]));


