
const numbers = [3,23,44,3,111,12,21];
numbers.sort();