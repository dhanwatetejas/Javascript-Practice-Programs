let x= "1";
let y = "0";
let z= x+y;
console.log(z);

const Tarikh = new Date();
console.log(Tarikh);
