// const me ={
//     talk(){
//         console.log("Me is talking");
//     }
// }
// const you ={
//     talk(){
//         console.log("You are talking");
//     }
// }
// me.talk();
// you.talk();
const ann = {
    name: 'Ann',
    talk(){
        console.log(this.name+" is talking");
        
    }
}

const ben = {
    name: 'Ben',
    talk(){
        console.log(this.name+" is talking");
        
    }
}
ann.talk();
ben.talk();