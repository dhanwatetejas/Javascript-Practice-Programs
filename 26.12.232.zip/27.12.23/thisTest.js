function talk(){
    return this;
}
talk();
const me = {
    name: 'tejas',
    talk
}
me.talk();
