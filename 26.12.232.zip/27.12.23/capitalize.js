function capital(name){
    return name
}
console.log( capital('johnny'));