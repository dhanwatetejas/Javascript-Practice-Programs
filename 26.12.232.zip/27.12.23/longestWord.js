function longestWord(str){
    let words = str.split(" ");
    let longestWord = '';
    for(let word of words){
        if(word.length > longestWord.length){
            longestWord=word;
        }
    }
    console.log("the longest word is ="+ longestWord);
    return str;

}
console.log(longestWord("if and the longest wording from the following"));