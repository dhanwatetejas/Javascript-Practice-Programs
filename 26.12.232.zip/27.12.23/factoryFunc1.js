function myName(name){
    return{
        talk(){
        return console.log("My name is "+ name);
    }
}
}
const tejas = myName("Tejas");
tejas.talk();
const human ={
    kind :'Human'
}
const test = Object.create(human);
console.log(test);