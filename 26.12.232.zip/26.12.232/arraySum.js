const arr = [10,20,30];
let sum =0;
for(let i = 0;i<arr.length;i++){
sum = sum+arr[i];
}
console.log(sum);
let average = sum/arr.length;
console.log(average);
console.log(arr.reverse());