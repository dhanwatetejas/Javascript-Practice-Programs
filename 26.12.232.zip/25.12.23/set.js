const letters = new Set();
letters.add("a");
letters.add("b");
letters.add("c");
const a = letters.values();
letters.add("d");
console.log(a);
